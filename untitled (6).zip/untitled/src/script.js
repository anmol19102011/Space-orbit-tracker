// Counter animation
const counters = document.querySelectorAll('.number');

counters.forEach(counter => {
  const updateCounter = () => {
    const target = +counter.getAttribute('data-target');
    const current = +counter.innerText;
    const increment = Math.ceil(target / 100);

    if (current < target) {
      counter.innerText = current + increment;
      setTimeout(updateCounter, 25);
    } else {
      counter.innerText = target.toLocaleString() + "+";
    }
  };
  updateCounter();
});

// Cursor glow
const glow = document.querySelector('.cursor-glow');
document.addEventListener('mousemove', (e) => {
  glow.style.left = e.clientX + 'px';
  glow.style.top = e.clientY + 'px';
});

// Facts slider
const facts = document.querySelectorAll('.fact-card');
let factIndex = 0;

setInterval(() => {
  facts[factIndex].classList.remove('active');
  factIndex = (factIndex + 1) % facts.length;
  facts[factIndex].classList.add('active');
}, 3000);

// Quiz
let score = 0;

function checkAnswer(button, isCorrect) {
  const question = button.parentElement;
  const buttons = question.querySelectorAll('button');

  if (question.classList.contains('answered')) return;

  question.classList.add('answered');

  buttons.forEach(btn => {
    btn.disabled = true;
  });

  if (isCorrect) {
    button.classList.add('correct');
    score++;
  } else {
    button.classList.add('wrong');
    buttons.forEach(btn => {
      if (btn.getAttribute('onclick').includes('true')) {
        btn.classList.add('correct');
      }
    });
  }

  document.getElementById('quizResult').innerText = `Your Space IQ: ${score}/3`;
}

// Background Music Toggle
const musicBtn = document.getElementById("musicBtn");
const bgMusic = document.getElementById("bgMusic");

let isPlaying = false;

musicBtn.addEventListener("click", () => {
  if (!isPlaying) {
    bgMusic.play();
    bgMusic.volume = 0.25;
    musicBtn.innerText = "⏸ Pause Music";
    isPlaying = true;
  } else {
    bgMusic.pause();
    musicBtn.innerText = "🎵 Play Music";
    isPlaying = false;
  }
});

// Chart.js
const script = document.createElement("script");
script.src = "https://cdn.jsdelivr.net/npm/chart.js";
script.onload = () => {
  const ctx = document.getElementById('launchChart').getContext('2d');
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: ['USA', 'Russia', 'China', 'India', 'Europe', 'Others'],
      datasets: [{
        label: 'Satellite Contribution',
        data: [45, 15, 18, 7, 8, 7],
        backgroundColor: [
          '#38bdf8',
          '#8b5cf6',
          '#22d3ee',
          '#06b6d4',
          '#818cf8',
          '#c084fc'
        ],
        borderRadius: 10
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          labels: { color: 'white' }
        }
      },
      scales: {
        x: {
          ticks: { color: 'white' },
          grid: { color: 'rgba(255,255,255,0.08)' }
        },
        y: {
          ticks: { color: 'white' },
          grid: { color: 'rgba(255,255,255,0.08)' }
        }
      }
    }
  });
};
document.head.appendChild(script);